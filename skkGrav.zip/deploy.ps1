    

compress-Archive -Path .\ -DestinationPath package.zip

cp -r -pw mugojustus -i C:\Users\mugpet\Documents\public_key.ppk  package.zip skovbokarate.dk@ssh.skovbokarate.dk:public_html
