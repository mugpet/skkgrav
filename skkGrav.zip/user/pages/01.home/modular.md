---
title: Skovbo Karate Klub
menu: Start
onpage_menu: true
content:
    items: @self.modular
    order:
        by: default
        dir: asc
        custom:
            - _text
            - _news
---
