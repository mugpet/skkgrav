---
hidemenu: true
title: Text
text:
  - content: 
    css_suffix: wp-7
  - content: 
    css_suffix: wp-8
---
### Velkommen til Skovbo Karate Klub's hjemmeside.

I Skovbo Karate Klub træner vi Okinawa Goju-Ryu Karate Do. Klubben er medlem af Jundokan Danmark/Norge som er den danske afdeling under O.G.K.K i Okinawa.

Goju-ryu Karate Do stammer fra Okinawa som er en lille ø der ligger ca. 1500 km. syd for Tokyo. Goju-ryu Karate Do, som betyder den hårde (GO) og bløde (JU) skole (RYU) for den tomme (KARA) hånds (TE) vej (DO), blev grundlagt af Chojun Myagi Sensei, og er i dag en af de mest trænede karate stilarter i verden.

## Overskrift 
det virker fint
´her er lidt kodt tekst´
