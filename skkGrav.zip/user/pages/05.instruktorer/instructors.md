---
title: Instruktører
teaminstructors:
    -   name: Mugo Petersen
        title: 5. Dan, Sensei
        description: Ichiban <br/> Matayoshi Kobudo
        avatar: "https://sites.google.com/site/jundokandanmark/_/rsrc/1345147241654/blackbelts/Mugo%20Petersen%20Sensei%20095.jpg?height=200&width=133" 

    -   name: Brian Munk
        title: 3. Dan, Sempai
        description: Matayoshi Kobudo
        avatar: "https://dl.dropboxusercontent.com/u/12375/skk/skk.hyperesources/IMG_7047%20%281%29.png"   
           
    -   name: Yogan Aruliah
        title: 3. Dan, Sempai
        description: Matayoshi Kobudo
        avatar: "https://dl.dropboxusercontent.com/u/12375/skk/skk.hyperesources/IMG_7022%20%281%29.png" 

    -   name: Jette Jensen
        title: 2. Dan, Sempai
        description: Børneholdet <br/> Klubindkøber
        avatar: "https://dl.dropboxusercontent.com/u/12375/skk/skk.hyperesources/IMG_0413.jpg"  

    -   name: David Aruliah
        title: 2. Dan, Sempai
        description: Ung/Voksen & Ichiban
        avatar: "https://scontent-arn2-1.xx.fbcdn.net/v/t1.0-9/12313828_805627356249785_7994160570672710662_n.png?oh=7ec3c96b529115bd8a0cf46ba4afeaf3&oe=591A6612"  

    -   name: Martin Jensen
        title: 2. Dan, Sempai
        description: Ung/Voksen
        avatar: "https://sites.google.com/site/jundokandanmark/_/rsrc/1387027373714/blackbelts/IMG_2076%20-%20Version%204.jpg?height=200&width=133"  

    -   name: Jim Wishshaw
        title: 2. Dan, Sempai
        description: Børneholdet
        avatar: "/user/assets/Jim.jpg"  

    -   name: Kenneth Nimann Westergaard
        title: 1. Dan, Sempai
        description: Børneholdet <br/> Fredagsholdet
        avatar: "/user/assets/Kenneth.jpg"  

blackbelts:
    -   name: Anders Paw Sørensen
        title: 2. Dan, Sempai
        description: 
        avatar: "/user/assets/Anders_3.jpg"  

    -   name: Martin Meiner
        title: 2. Dan, Sempai
        description: 
        avatar: "https://scontent-arn2-1.xx.fbcdn.net/v/t31.0-8/12469596_823988437747010_8476192640801419054_o.jpg?oh=b1823cea058ea3d16e94678004be2fb2&oe=590189BD"

    -   name: Dennis Clemmensen
        title: 2. Dan, Sempai
        description: Matayoshi Kobudo
        avatar: "https://sites.google.com/site/jundokandanmark/blackbelts/IMG_0396.jpg"

    -   name: Henrik Jensen
        title: 1. Dan, Sempai
        description: 
        avatar: "http://farm7.static.flickr.com/6004/5900415521_4035502fc6_b.jpg"

    -   name: Sebastian Daniel Hansen
        title: 1. Dan, Sempai
        description: 
        avatar: "https://sites.google.com/site/jundokandanmark/blackbelts/IMG_0390.jpg"

    -   name: Jesper Rajczyk Pedersen
        title: 1. Dan, Sempai
        description: 
        avatar: "https://lh4.googleusercontent.com/CfAzlQL6RzBj9vyTxsVIEgIKTNaOlvhPDgOtngYkQ0qBg_6O35EL1uKPyxcfO3NfOgJlaT1SkQ=w70"

    -   name: Joachim Skou Rasmussen
        title: 1. Dan, Sempai
        description: 
        avatar: "https://lh3.googleusercontent.com/XM0hcFc9LfzY3IUeMONkrCiTBtN9Aky7ooFAjiQNCtkIXBOyMsbtwwfj6pWA1cB9wB4deL4=w70"

    -   name: Tea Røgilds-Heinsøe
        title: 1. Dan, Sempai
        description: 
        avatar: "https://scontent-arn2-1.xx.fbcdn.net/v/t1.0-9/12316404_805627369583117_5006442379565322120_n.png?oh=66d30f94535ba4e3c648533345e0cbd6&oe=590388ED"

    -   name: Christina Rajczyk Ginnerrup
        title: 1. Dan, Sempai
        description: 
        avatar: "https://scontent-arn2-1.xx.fbcdn.net/v/t1.0-9/12316153_805627349583119_465072670480309516_n.png?oh=dadc4b3ed3f194d9ce0e9812d094043b&oe=59463BC4"

    -   name: Michell Grandahl Christensen
        title: 1. Dan, Sempai
        description: 
        avatar: "/user/assets/Michell_3.jpg"  

    -   name: Lisa Aalbæk
        title: 1. Dan, Sempai
        description: 
        avatar: "/user/assets/Lisa2.jpg"


    -   name: Bo Niels Rosenberg
        title: 1. Dan, Sempai
        description: 
        avatar: "https://lh6.googleusercontent.com/Td9beB1kxV9hxb5ft3PIlAdvYYLPiCLrT2LHmqpPEtHpQPKBOppFJ9WiHOrtUP3Nt2xoye8L=w70"


    -   name: Maibritt Brohus Rasmussen
        title: 1. Dan, Sempai
        description: 
        avatar: "/user/assets/Maibritt_1.jpg"


brownbelts:
    -   name: Theban Aruliah
        title: 1. Kyu, Sempai
        description: 
        avatar: ""

    -   name: Lykke Laura Hansen
        title: 2. Kyu, Sempai
        description: 
        avatar: "/user/assets/Lykke_1.jpg"

    -   name: Marianne Røgilds-Heinsøe
        title: 3. Kyu, Sempai
        description: 
        avatar: "https://scontent-arn2-1.xx.fbcdn.net/v/t31.0-8/12487205_823988434413677_5925825752270170933_o.jpg?oh=24d0d85392d780079bc8e58947ef89c4&oe=59153E2E"


    -   name: Ulrik Maribo Pedersen
        title: 3. Kyu, Sempai
        description: 
        avatar: ""

    -   name: Bo Søgaard
        title: 3. Kyu, Sempai
        description: 
        avatar: "/user/assets/Bo_S%C3%B8ndergaard_1.jpg"

    -   name: Miichael Elkjær
        title: 3. Kyu, Sempai
        description: 
        avatar: "/user/assets/Miichael_1.jpg"

    -   name: Jørgen Egløkke
        title: 3. Kyu, Sempai
        description: 
        avatar: "/user/assets/Jørgen_1.jpg"

    -   name: Claus William Hansen
        title: 3. Kyu, Sempai
        description: 
        avatar: "/user/assets/Claus_1.jpg"

    -   name: Sille Kruuse
        title: 3. HO Kyu, Sempai
        description: 
        avatar: ""

    -   name: Josephine Rosenberg
        title: 3. HO Kyu, Sempai
        description: 
        avatar: "/user/assets/JosephineRosenberg.jpg"

    -   name: Stephanie Rosenberg
        title: 3. HO Kyu, Sempai
        description: 
        avatar: "/user/assets/StephanieRosenberg.jpg"

    -   name: Kevin Nimann
        title: 3. HO Kyu, Sempai
        description: 
        avatar: ""

    -   name: Sander
        title: 3. HO Kyu, Sempai
        description: 
        avatar: "/user/assets/Sander_1.jpg"

---