---
title: Børneholdet
text:
  - content: 
    css_suffix:
  - content:  
    css_suffix:
---

# Børneholdet

Børn kan med fordel træne karate som et led i deres fysiske, og psykiske udvikling. I Skovbo karate klub lægger vi vægt på tekniktræning (slag. spark og parader), og kata-træning (solo kamp serie). Både teknik og kata-træning, er med til at øge børnenes styrke, hastighed, koncentration ,og især deres koordinationsevne bliver udfordret. Disciplin en vigtig del af karate, derfor vil børn der træner karate lære at være bevidste om hvordan de er overfor andre mennesker, og deres omgivelser.

## Træningstider og instruktører

Skovbo karate klubs børnehold træner hver **tirsdag fra kl. 18:00-19:30*. Som nybegynder træner man som regel fra 18:00-19:00**. Børneholdet trænes af Sempai Jette Jensen, som har trænet karate i Skovbo siden klubben blev stiftet i april 2003. Sempai Jette ledsages af Sempai Jim og Sempai Kenneth, som sammen udgør et stærkt instruktørteam. Vi har mange engageret udøvere i klubben, så der er også en del høregraduerede udøvere der hjælper med træningen.

## Hvornår kan man starte

For at træne på børneholdet skal man være fyldt **7 år**. Vi tager løbende medlemmere i klubben, men for at få den bedste start skal man forsøge at starte i perioderne august til oktober og januar til marts. Udøvere på børneholdet kan træne på holdet til de fylder **12 år**, herefter skal man flytte til ung/voksen holdet. Man kan skifte til Ung/ voksen holdet når man fylder **10 år**.


 Kontingent   
  Børneholdet betaler en årlig kontingent på **300,- kr**.
