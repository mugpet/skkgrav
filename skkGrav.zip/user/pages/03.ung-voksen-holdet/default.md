---
title: 'Ung/Voksen holdet'
---

# Ung-voksen holdet

I Skovbo Karate Klub træner vi Goju-ryu karate, hvor vi lægger stor vægt på kamp-, kata-, og tekniktræning. Smidighed, styrke, koordinering og udholdenhed er en naturlig del af træningen. Disciplinen er moderat og vi stræber efter at have en åben og positiv atmosfære.

Som udøver af Goju-ryu karate-do i Skovbo Karate Klub får du lejlighed til at deltage i karatestævner, kurser, seminarer (Gasshuku), og på den måde møde andre karateudøvere fra andre karateklubber. Med tiden vil du også blive introduceret til Kobudo (våbentræning), hvor du i første omgang kommer til at træne med Jo og Hanbo.

Karatetræningen for unge og voksne foregår om **onsdagen fra kl. 18:00 til 20:00**. For at starte til karate på dette hold skal du være fyldt **10 år**. Børn under 10 år træner på børneholdet.

## Kontingent

Årlig kontingent på **400,- kr for medlemmer over 12 år og 300,- kr. for medlemmer under 12 år**

