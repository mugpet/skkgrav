---
title: Pages

access:
    admin.pages: true
    admin.super: true
---
