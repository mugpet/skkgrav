---
title: Forgot password

login_redirect_here: false

form:

    fields:
        - name: email
          type: text
          label: PLUGIN_LOGIN.EMAIL
          autofocus: true
          validate:
            required: true
            type: email
---


# Recover your password

Enter your email to recover your password
